const mobileMenu = document.getElementById('mobile-menu');
const navList = document.querySelector('.nav-list');

// Toggle the menu when hamburger is clicked
mobileMenu.addEventListener('click', () => {
    navList.classList.toggle('active');
});

// Optional: Close menu when a link is clicked
document.querySelectorAll('.nav-list li a').forEach(link => {
    link.addEventListener('click', () => {
        navList.classList.remove('active');
    });
});